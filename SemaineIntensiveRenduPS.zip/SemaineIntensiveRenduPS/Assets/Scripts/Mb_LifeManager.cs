﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mb_LifeManager : MonoBehaviour
{
    public float currentLife;
    public Mb_Poolable fxDeath;
}
