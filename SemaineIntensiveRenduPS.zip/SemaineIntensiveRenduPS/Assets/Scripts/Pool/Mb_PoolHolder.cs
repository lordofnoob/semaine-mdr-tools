﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Mb_PoolHolder : MonoBehaviour
{
    public List<Mb_Poolable> listOfItem;
}
