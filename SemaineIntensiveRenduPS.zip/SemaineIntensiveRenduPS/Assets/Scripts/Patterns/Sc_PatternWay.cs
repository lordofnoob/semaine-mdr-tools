﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class Sc_PatternWay : ScriptableObject
{
    public Vector3[] patern;
}
