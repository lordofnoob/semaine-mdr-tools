﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;


public class Mb_PatternGenerator : MonoBehaviour
{
    public Vector3[] patern;
}
